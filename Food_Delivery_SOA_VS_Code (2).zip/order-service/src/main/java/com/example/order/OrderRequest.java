package com.example.order;

import java.util.List;

public record OrderRequest(int userId, int restaurantId, List<String> items) {
}
