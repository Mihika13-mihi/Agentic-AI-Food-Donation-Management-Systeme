FOOD DELIVERY SOA SYSTEM — VS CODE EXECUTION
Based on your Skill Experiment 1 document.

WHAT YOU NEED
1. Java JDK 17 or later
2. Apache Maven
3. Visual Studio Code
4. VS Code extensions: Extension Pack for Java (recommended)
5. Postman (optional; the restaurant GET endpoint also works in your browser)

CHECK INSTALLATION
Open VS Code -> Terminal -> New Terminal and run:
    java -version
    mvn -version
Both commands should work. Java should be version 17 or later.

OPEN THE PROJECT
1. Extract this ZIP file.
2. In VS Code, choose File -> Open Folder.
3. Open the extracted Food_Delivery_SOA_VS_Code folder.
4. Keep this README open while following the steps.

RUN RESTAURANT SERVICE (PORT 8080)
1. In VS Code, open Terminal -> New Terminal.
2. Run:
    cd restaurant-service
    mvn spring-boot:run
3. Wait until the terminal says the application has started.
4. Open this URL in your browser:
    http://localhost:8080/restaurants
5. You should see two restaurant records in JSON format.
6. Leave this terminal running.

RUN ORDER SERVICE (PORT 8081)
1. Open another terminal using Terminal -> New Terminal.
2. Run:
    cd order-service
    mvn spring-boot:run
3. Wait until the application has started.
4. Leave this terminal running too.

TEST THE ORDER SERVICE
Option A — using Postman:
1. Create a new request and select POST.
2. Enter:
   http://localhost:8081/orders
3. Select Body -> raw -> JSON.
4. Paste:
   {
     "userId": 1001,
     "restaurantId": 101,
     "items": ["Biryani", "Chicken 65"]
   }
5. Click Send.
6. Expected response begins with:
   Order placed successfully:

Option B — using curl in a third VS Code terminal:
    curl -X POST http://localhost:8081/orders -H "Content-Type: application/json" -d "{\"userId\":1001,\"restaurantId\":101,\"items\":[\"Biryani\",\"Chicken 65\"]}"

IMPORTANT
- Keep both service terminals running while testing.
- Restaurant service uses port 8080.
- Order service uses port 8081.
- If you see "Port already in use", close the other program using that port or stop the duplicate service.
- To stop a service, click its terminal and press Ctrl+C.
- If `mvn` is not recognized, install Apache Maven and reopen VS Code.
- If Java version is below 17, install JDK 17 or later and set JAVA_HOME/PATH.

SCREENSHOTS FOR YOUR LAB RECORD
Take one screenshot of http://localhost:8080/restaurants showing the JSON.
Take another screenshot of the successful POST request in Postman.

EXPERIMENT RESULT
The Food Delivery SOA system has two independent REST services: Restaurant Service on port 8080 and Order Service on port 8081. They expose GET /restaurants and POST /orders and use JSON data contracts.
