package com.example.restaurant;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestaurantController {

    @GetMapping("/restaurants")
    public List<Restaurant> getRestaurants() {
        return List.of(
            new Restaurant(101, "Pista House Restaurant", "Bachupally"),
            new Restaurant(102, "Kritinga Restaurant", "Nizampet")
        );
    }
}
