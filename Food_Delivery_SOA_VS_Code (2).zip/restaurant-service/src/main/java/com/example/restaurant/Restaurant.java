package com.example.restaurant;

public record Restaurant(int id, String name, String location) {
}
